How to run the Game
-------------------
Just run:
    game.exe

System Requirements
-------------------
 * 8086 / 8088 CPU
 * 640kb of RAM
 * VGA/MCGA graphics card (or compatible)
 * Adlib soundcard (or compatible)

Website
-------
https://terrysoba.github.io/TandyGame/


Git Revision
------------
4294725c1c1ca9c70a86e58ecac7113a5625e7e9
