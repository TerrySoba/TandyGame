How to run the Game
-------------------
Just run:
    game.exe

System Requirements
-------------------
 * 8086 / 8088 CPU
 * 640kb of RAM
 * VGA/MCGA graphics card (or compatible)
 * Adlib soundcard (or compatible)

Website
-------
https://terrysoba.github.io/TandyGame/


Git Revision
------------
eb1b8cd5ab10671dbd5f49f7cf6a880085950782
